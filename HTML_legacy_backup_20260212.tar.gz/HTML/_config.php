<?php
$inc_path="inc/";
include($inc_path."_config.php");
include($inc_path."_web_func.php");
?>