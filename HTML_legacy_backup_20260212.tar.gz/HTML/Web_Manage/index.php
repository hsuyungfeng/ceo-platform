<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>一企實業有限公司管理後台</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<frameset framespacing="0" id=frameset border="false" rows="46,*,40"  frameborder="0">
<frame name="top" id="top"  scrolling="no" marginwidth="0" marginheight="0" src="top.php">
<frameset name=mm id=mm cols="180,*" frameborder="NO" border="0" framespacing="0"> 
  <frame name="left" id="left"  scrolling="yes" marginwidth="0" marginheight="0" src="left.php">
  <frame name="main" id="main" scrolling="yes" marginwidth="0" marginheight="0" src="main.php">
</frameset>
<frame name="bottom" id="bottom"  scrolling="no" marginwidth="0" marginheight="0" src="bottom.php">
  </frameset>
  <noframes>
<body>
  <p>This page uses frames, but your browser doesn't support them.</p>
  </body>
  </noframes>

  </html>