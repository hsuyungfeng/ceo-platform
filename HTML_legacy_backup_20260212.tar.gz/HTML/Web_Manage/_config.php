<?php
include $inc_path."_config.php";
include $inc_path."_web_func.php";
$sid=session_id();

if(!isset($_SESSION["madmin"]) || !isset($_SESSION["userid"]))
 {
      echo "<script type='text/javascript'>window.open('".$manage_path."login.html','_top');</script>";
      exit;  
 }
 
 function isExist($table,$field,$val,$where){
	global $db;
	$row=$db->query_first("select $field  from $table where $field=$val $where",$field);
	return ($row) ? true : false;
}
 								   

function reviewPic($reviewpic){
	global $managepath;
	echo (trim($reviewpic)=="") ? "" : "<a href='$managepath$reviewpic' target='_blank'>�s��</a>";
}

function getOrder($order,$table,$field,$nid,$where){ //�W���U����function
	global $db;
	$sql="";
	$row=$db->query_first("select $field from $table where id=".$nid);
	$ind=$row[$field];

	if ($order=="down"){
		$sql="Select  id as id,$field as field from $table where  $field < $ind  $where order by $field desc limit 1 ";
	}
	else{
		$sql="Select  id as id ,$field as field from $table where  $field > $ind $where order by $field limit  1 ";
	}

	$row=$db->query_first($sql);
	if ($row){
		$new_nid=$row["id"];   //�n�����Ǫ�id
		$new_ind=$row["field"];//�s������
	
		$db->query("update $table set $field=$new_ind where id=$nid"); //�N���wid����s����
		$db->query("update $table set $field=$ind where id=$new_nid"); //�N�n�����Ǫ�id�����¶���
	}
}
function getMaxInd($table,$field,$where){
	global $db;
	$row=$db->query_first("select max($field) as max from $table $where","max");
	$maxind=intval($row["max"]);
	
	if ($maxind==0){
		$maxind=1;
	}
	else{
		$maxind+=5;
	}
	return $maxind;
}
?>